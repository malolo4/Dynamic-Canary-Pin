#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>


int exito() {
	printf ("SUCCESS!!!\n");
}


int funcion()
{
	char other [5] = "local"; 	//local variable (buffer)
	char buffer[10];		//buffer to store the input
	int bytes;

	printf("Say a name:\n");
	bytes = read(0, buffer,100);
	printf ("Hi %s\n", buffer);
	printf ("Value of the other buffer: %s\n", other);
	return(0);
}


int main(){
	funcion();
}

