#include <cstdio> //Similar a <stdio.h>
#include <iostream> //For cin, cout and cerr.
#include <string>
#include <cstring> //Similar a <string.h>
#include <vector>
#include "pin.H"

FILE * fout;  //Output file

typedef struct Canary
{
    string _rtn_name;
    ADDRINT _ini_ebp;
    ADDRINT _ini_eip;
    ADDRINT _ini_address;
    ADDRINT _fini_ebp;
    ADDRINT _fini_eip;
    ADDRINT _fini_address;
    bool _test; //Show if a routine has passed the test or not.
} CANARY;

vector<CANARY *> V_Canary;

/*
Argument the defines the output file name. The defautl value is:
BOFtest.out
*/
KNOB<string> KnobOutputFile(KNOB_MODE_WRITEONCE, "pintool",
    "o", "BOFtest.out", "specify output file name");
/*
Argument that spicify whether the programs ends, if a attack against the stack is performed,
or continues ignoring the attack. The default value is 1. The value 1 means the program is 
aborted and the value 0 means it continues.
*/
KNOB<bool> KnobAbort(KNOB_MODE_WRITEONCE, "pintool",
    "a", "1", "specify whether the program ends or not: 0 -> false, program continues ; 1 -> true, program is aborted");

/*
This function checks if the current routine is already been monitored or not.
*/
VOID check_routine(TRACE trace, bool * mon, int * pos)
{
    if(!V_Canary.empty())
    {
        for(unsigned int i = 0; i < V_Canary.size(); i++)
        {
            if((strcmp(V_Canary[i]->_rtn_name.c_str(),RTN_Name(TRACE_Rtn(trace)).c_str())==0))
            {
                *mon = true;
                *pos = i;
            }
        }
    }
}

/*
This function prints the results of the analysis in the output file. 
First, it shows the functions that had a successful analysis and 
then the functions that had a failed analysis.
*/
VOID finish()
{
    printf("In the '%s' file you will find the %lu functions examined.\n", KnobOutputFile.Value().c_str(), (unsigned long int) V_Canary.size());

    if(V_Canary.size() != 0)
    {
        for(unsigned int i = 0; i < V_Canary.size(); i++)
        {
            if(V_Canary[i]->_test){
                fprintf(fout, "\n[+] Function: %s() at 0x%.8lx - 0x%.8lx\n", V_Canary[i]->_rtn_name.c_str(), (unsigned long int) V_Canary[i]->_ini_address, (unsigned long int) V_Canary[i]->_fini_address);
                fprintf(fout, "\tsaved ebp: 0x%.8lx\n", (unsigned long int) V_Canary[i]->_ini_ebp);
                fprintf(fout, "\tsaved eip: 0x%.8lx\n", (unsigned long int) V_Canary[i]->_ini_eip);
                fprintf(fout, "\tCanary verification: SUCCESS\n");
                fprintf(fout, "\t\tchecked ebp: 0x%.8lx\n", (unsigned long int) V_Canary[i]->_fini_ebp);
                fprintf(fout, "\t\tchecked eip: 0x%.8lx\n", (unsigned long int) V_Canary[i]->_fini_eip);
            }
        }
        //Aquí puesdo hacer un solo bucle lo unico que se mezclan los fail y los exitos (un for con los dos if)
        for(unsigned int i = 0; i < V_Canary.size(); i++)
        {
            if(!(V_Canary[i]->_test)){
                fprintf(fout, "\n[!] Function: %s() at 0x%.8lx - 0x%.8lx\n", V_Canary[i]->_rtn_name.c_str(), (unsigned long int) V_Canary[i]->_ini_address, (unsigned long int) V_Canary[i]->_fini_address);
                fprintf(fout, "\tsaved ebp: 0x%.8lx\n", (unsigned long int) V_Canary[i]->_ini_ebp);
                fprintf(fout, "\tsaved eip: 0x%.8lx\n", (unsigned long int) V_Canary[i]->_ini_eip);
                fprintf(fout, "\tCanary verification: FAIL\n");
                fprintf(fout, "\t\tchecked ebp: 0x%.8lx\n", (unsigned long int) V_Canary[i]->_fini_ebp);
                fprintf(fout, "\t\tchecked eip: 0x%.8lx\n", (unsigned long int) V_Canary[i]->_fini_eip);
            }
        }
    }
}

/*
For a given element of the structs vector, the function checks if 
the values of the registers (ebp and eip) at the begining are the
same than the values of the same registers at the end of the routine.
If they are the same, the routine passes the test, but if not, the 
test is falied. The program could end here if the abort variable is true.
*/
VOID test_registers(CANARY * cny)
{
    if(!(cny->_ini_ebp == cny->_fini_ebp && cny->_ini_eip == cny->_fini_eip))
    {
        cny->_test = false;
        if(KnobAbort.Value()){
            finish();
            exit(0);
        }
    }
    else{
        cny->_test = true;
    }

}

/*
The function saves the value pointed by the esp register (ebp) and the value 
sizeof(ADDRINT) positions above the value pointed by the esp (eip).
It is called at the begining of the routine.
*/
VOID read_ini_register(ADDRINT * registro_ebp, ADDRINT * registro_eip, ADDRINT esp)
{
    PIN_SafeCopy(registro_ebp, reinterpret_cast<void *>(esp), sizeof(ADDRINT));
    PIN_SafeCopy(registro_eip, reinterpret_cast<void *>(esp+sizeof(ADDRINT)), sizeof(ADDRINT));
}

/*
The function saves the value of the ebp register and the value pointed by 
the esp register (eip). Also it calls the test_registers() function to check
the saved values. It is called at the end of the routine. 
*/
VOID read_fini_register(ADDRINT * registro_ebp, ADDRINT * registro_eip, ADDRINT ebp, ADDRINT esp, ADDRINT pos)
{
    *registro_ebp = ebp;
    PIN_SafeCopy(registro_eip, reinterpret_cast<void *>(esp), sizeof(ADDRINT));
    test_registers(V_Canary[pos]);
}
/*
Pin calls this function every time a new basic block is encountered. The 
function checks if the routine belongs to the main program and if it is
already being monitored. If not the function checks if the begining of 
the routine is a push %ebp instruction to know if the routine is an 
objective. The function introduce the callbacks in the objective routines.
*/
VOID Trace(TRACE trace, VOID *v)
{
    RTN rtn = TRACE_Rtn(trace);
    IMG img = IMG_FindByAddress(TRACE_Address(trace));
    bool mon = false; 
    int pos = -1; 

    if (!RTN_Valid(rtn))
    {
        return;
    }

    if(!IMG_Valid(img) || !IMG_IsMainExecutable(img)) return;

    check_routine(trace, &mon, &pos);

    if(!mon)
    {
        INS ins_ini = BBL_InsHead(TRACE_BblHead(trace));
        //First operation is a push %ebp
        if(INS_Address(ins_ini) == RTN_Address(TRACE_Rtn(trace)) && INS_IsStackWrite(ins_ini) && !INS_IsCall(ins_ini) && INS_OperandReg(ins_ini, 0) == REG_GBP)
        {
            RTN_Open(rtn);
            INS last_ins = RTN_InsTail(rtn);
            RTN_Close(rtn);

            if(INS_IsRet(last_ins))
            {
                CANARY * cny = new CANARY;
                cny->_rtn_name = RTN_Name(rtn);
                cny->_ini_address = RTN_Address(TRACE_Rtn(trace));
                cny->_fini_address = INS_Address(last_ins);
                //Callback after the execution of the instruction push %ebp
                INS_InsertCall(ins_ini, IPOINT_AFTER, (AFUNPTR) read_ini_register,IARG_PTR, &(cny->_ini_ebp), IARG_PTR, &(cny->_ini_eip), IARG_REG_VALUE, REG_STACK_PTR, IARG_END);
                V_Canary.push_back(cny);
                mon = true;
                pos = V_Canary.size()-1;
            }
            
        }
    }
    if(mon)
    {
        INS ins_fini = BBL_InsTail(TRACE_BblTail(trace));

        if(INS_IsRet(ins_fini) && INS_Address(ins_fini) == V_Canary[pos]->_fini_address)
        {   
            //Callback before the execution of the ret instruction
            INS_InsertCall(ins_fini, IPOINT_BEFORE, (AFUNPTR)read_fini_register, IARG_PTR, &(V_Canary[pos]->_fini_ebp), IARG_PTR, &(V_Canary[pos]->_fini_eip), 
                IARG_REG_VALUE, REG_GBP, IARG_REG_VALUE, REG_STACK_PTR, IARG_ADDRINT, pos, IARG_END);
        }
    }
}
/*
This function is called when the application exits.
It calls finish() function to show the results.
*/
VOID Fini(INT32 code, VOID *v)
{
    printf("The program hasn't been aborted by the pintool.\n");
    finish();
}

/* ===================================================================== */
/* Print Help Message                                                    */
/* ===================================================================== */

INT32 Usage()
{
    cerr << endl << "This tool protects the stack against buffer overflow attacks," << endl
    << "using a method based on canary protection."<< endl;
    cerr << endl << KNOB_BASE::StringKnobSummary() << endl;
    return -1;
}

/* ===================================================================== */
/* Main                                                                  */
/* ===================================================================== */

int main (int argc, char * argv[])
{

    //Initialize symbol table code, needed for rtn instrumentation
    PIN_InitSymbols();

    // Initialize pin
    if (PIN_Init(argc, argv)) return Usage();

    fout = fopen(KnobOutputFile.Value().c_str(), "w");

    TRACE_AddInstrumentFunction(Trace, 0);

    //Register Fini to be called when the application exits
    PIN_AddFiniFunction(Fini, 0);
    
    // Start the program, never returns
    PIN_StartProgram();
    
    return 0;

}