#!/bin/bash

echo "You need build-essential package (gcc, g++, make...)!"
echo "If you don't have it intalled, a warning error can be throw." 
program=pin-3.7-97619-g0d0c92f4f-gcc-linux
route_download=$PWD
dir_tool=StackProtection #tool's folder
cd ~

echo 'Downloading Pin...'
wget https://software.intel.com/sites/landingpage/pintool/downloads/$program.tar.gz
echo 'Done'


echo 'Installing Pin...'
tar zxf $program.tar.gz
echo 'Done'
cd $program/source/tools

#Move and compile the code
cp -r $route_download/$dir_tool $PWD #Copy of a file
cd $dir_tool
make obj-ia32/canary.so TARGET=ia32
make obj-intel64/canary.so TARGET=intel64
./compilar "test" 

#Add script to PATH
cd ../../../
cp $route_download/canarypin $PWD
echo "Adding canarypin (launcher) to PATH..."
sudo ln -s "$HOME/$program/canarypin" /usr/bin
echo "Done"
